from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required, user_passes_test
from django.http import HttpResponse, JsonResponse
from django.contrib import messages
from django.db import transaction, IntegrityError
from django.template.loader import render_to_string
from io import BytesIO  # NOVO: Necessário para o buffer de PDF
from xhtml2pdf import pisa  # NOVO: O conversor de PDF
from django.contrib.auth import login, logout, authenticate, get_user_model
from django.core.mail import send_mail 
import random 
from datetime import date
from django.db.models import Prefetch
from django.conf import settings
from .models import Evento, Inscricao, Perfil, Certificado, RegistroAuditoria 
from .utils import log_auditoria
from django.contrib.auth.forms import AuthenticationForm
from django.db import transaction
from .forms import UserRegistrationForm, PerfilForm
from .models import Perfil
from .utils import log_auditoria
from .forms import UserRegistrationForm, PerfilForm, EventoForm

# REMOVIDO: from weasyprint import HTML, CSS (Substituído por xhtml2pdf)

User = get_user_model() 

# --- Decoradores de Permissão Customizados ---
def confirmar_email(request):
    """View para confirmação de e-mail (Requisito 7)."""
    # LIMPA TODAS AS MENSAGENS ANTIGAS (resolve o bug das mensagens repetidas)
    list(messages.get_messages(request))  # força consumo das mensagens velhas

    if request.method == 'POST':
        codigo = request.POST.get('codigo')
        email = request.POST.get('email')

def is_organizador(user):
    try:
        return user.is_authenticated and user.perfil.perfil == 'ORGANIZADOR'
    except Perfil.DoesNotExist:
        return False

def is_professor_ou_organizador(user):
    try:
        return user.is_authenticated and user.perfil.perfil in ['ORGANIZADOR', 'PROFESSOR']
    except Perfil.DoesNotExist:
        return False
    
# --- Views de Autenticação e Perfil ---

def home(request):
    """Página inicial que exibe os próximos 3 eventos ativos."""
    proximos_eventos = Evento.objects.filter(data_fim__gte=date.today()).order_by('data_inicio')[:3]
    return render(request, 'pages/home.html', {'eventos': proximos_eventos})
def login_view(request):
    """View de Login."""
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            
            log_auditoria(user, 'LOGIN', f"Usuário {user.username} logou no sistema.")
            
            if not user.perfil.email_confirmado:
                messages.warning(request, "Seu e-mail ainda não foi confirmado. Por favor, confirme para acesso completo.")
                
            return redirect(settings.LOGIN_REDIRECT_URL)
        else:
            messages.error(request, 'Usuário ou senha inválidos.')
    else:
        form = AuthenticationForm()
        
    return render(request, 'pages/login.html', {'form': form})

@login_required
def logout_view(request):
    log_auditoria(request.user, 'LOGOUT', f"Usuário {request.user.username} saiu do sistema.")
    logout(request)
    messages.success(request, 'Você saiu da sua conta.')
    return redirect(settings.LOGOUT_REDIRECT_URL)

from django.db import transaction # Certifique-se de importar transaction

@transaction.atomic
def registrar_usuario(request):
    # Inicializa formulários vazios para GET
    user_form = UserRegistrationForm()
    perfil_form = PerfilForm()

    if request.method == 'POST':
        user_form = UserRegistrationForm(request.POST)
        perfil_form = PerfilForm(request.POST)

        if user_form.is_valid() and perfil_form.is_valid():
            # 1. Cria o usuário (commit=True por padrão)
            user = user_form.save()

            # 2. Cria ou recupera o perfil (nunca vai dar duplicate aqui)
            perfil_data = perfil_form.cleaned_data
            codigo = str(random.randint(100000, 999999))

            perfil, criado = Perfil.objects.get_or_create(
                usuario=user,
                defaults={
                    'perfil': perfil_data['perfil'],
                    'instituicao': perfil_data.get('instituicao'),
                    'codigo_confirmacao': codigo,
                }
            )

            # Se por algum milagre o perfil já existia (ex.: race condition), só atualiza os campos
            if not criado:
                perfil.perfil = perfil_data['perfil']
                perfil.instituicao = perfil_data.get('instituicao')
                perfil.codigo_confirmacao = codigo
                perfil.save()

            # 3. Envia o e-mail de confirmação
            try:
                send_mail(
                    'Confirmação de E-mail SGEA',
                    f'Seu código de confirmação é: {codigo}\nUse-o nos próximos 10 minutos para ativar sua conta.',
                    settings.EMAIL_HOST_USER,
                    [user.email],
                    fail_silently=False,
                )
                messages.success(request, 'Registro realizado com sucesso! Verifique seu e-mail para o código de confirmação.')
            except Exception as e:
                messages.warning(request, 'Usuário criado, mas não foi possível enviar o e-mail de confirmação. Contate o administrador.')

            # 4. Log e redirecionamento
            log_auditoria(user, 'REGISTRO', f"Novo usuário registrado: {user.username} como {perfil.perfil}")
            
            # Opcional: já loga o usuário automaticamente ou não
            # login(request, user)

            return redirect('confirmar_email')

        else:
            # Mostra os erros dos formulários
            messages.error(request, 'Corrija os erros abaixo.')

    # GET ou POST com erro de validação
    context = {
        'user_form': user_form,
        'perfil_form': perfil_form,
    }
    return render(request, 'pages/registro.html', context)


def confirmar_email(request):
    # Limpa mensagens antigas (tira aqueles “corrija os erros” repetidos)
    list(messages.get_messages(request))

    if request.method == 'POST':
        codigo = request.POST.get('codigo')
        email = request.POST.get('email')

        # Agora aceita vários usuários com mesmo e-mail → pega o mais recente
        usuarios = User.objects.filter(email=email).order_by('-date_joined')

        if not usuarios.exists():
            messages.error(request, 'E-mail não encontrado.')
            return render(request, 'pages/confirmar_email.html')

        user = usuarios.first()  # pega o mais novo
        try:
            perfil = user.perfil
        except Perfil.DoesNotExist:
            messages.error(request, 'Perfil não encontrado.')
            return render(request, 'pages/confirmar_email.html')

        if perfil.email_confirmado:
            messages.info(request, 'Este e-mail já foi confirmado anteriormente.')
            return redirect('login')

        if perfil.codigo_confirmacao == codigo:
            perfil.email_confirmado = True
            perfil.codigo_confirmacao = None
            perfil.save()

            log_auditoria(user, 'CONFIRMACAO_EMAIL', 'E-mail confirmado com sucesso.')
            messages.success(request, 'E-mail confirmado com sucesso! Agora você pode fazer login.')
            return redirect('login')
        else:
            messages.error(request, 'Código inválido ou expirado.')

    return render(request, 'pages/confirmar_email.html')
# --- Views de Eventos ---

def lista_eventos(request):
    """Lista todos os eventos ativos."""
    eventos_ativos = Evento.objects.filter(data_fim__gte=date.today()).order_by('data_inicio')
    
    for evento in eventos_ativos:
        if request.user.is_authenticated:
            evento.inscrito = Inscricao.objects.filter(evento=evento, usuario=request.user).exists()
        else:
            evento.inscrito = False
            
    return render(request, 'pages/lista_eventos.html', {'eventos': eventos_ativos})


@login_required
@user_passes_test(is_organizador)
def criar_evento(request):
    if request.method == 'POST':
        form = EventoForm(request.POST, request.FILES)
        if form.is_valid():
            evento = form.save(commit=False)
            evento.organizador = request.user
            evento.save()
            
            log_auditoria(request.user, 'CRIACAO_EVENTO', f"Evento '{evento.titulo}' criado com sucesso.")
            messages.success(request, f'Evento "{evento.titulo}" criado com sucesso!')
            return redirect('meus_eventos')
        else:
            messages.error(request, 'Corrija os erros abaixo.')
    else:
        form = EventoForm()

    return render(request, 'pages/criar_evento.html', {'form': form})

def detalhe_evento(request, evento_id):
    """Detalhes de um evento e formulário de inscrição."""
    evento = get_object_or_404(
        Evento.objects.select_related('professor_responsavel', 'organizador'), 
        pk=evento_id
    )
    
    inscrito = False
    if request.user.is_authenticated:
        inscrito = Inscricao.objects.filter(evento=evento, usuario=request.user).exists()
        
    context = {
        'evento': evento,
        'inscrito': inscrito,
    }
    return render(request, 'pages/detalhe_evento.html', context)


@login_required
def inscrever_evento(request, evento_id):
    """Realiza a inscrição em um evento (Requisito 4)."""
    evento = get_object_or_404(Evento, pk=evento_id)

    if not request.user.perfil.email_confirmado:
        messages.error(request, 'Seu e-mail deve ser confirmado antes de se inscrever em eventos.')
        return redirect('detalhe_evento', evento_id=evento.id)

    if Inscricao.objects.filter(evento=evento, usuario=request.user).exists():
        messages.warning(request, 'Você já está inscrito neste evento.')
        return redirect('detalhe_evento', evento_id=evento.id)
        
    # Regra de Negócio: Capacidade Máxima
    if Inscricao.objects.filter(evento=evento).count() >= evento.quantidade_participantes:
        messages.error(request, 'O evento atingiu a capacidade máxima de participantes.')
        return redirect('detalhe_evento', evento_id=evento.id)
    
    try:
        with transaction.atomic():
            Inscricao.objects.create(evento=evento, usuario=request.user)
            log_auditoria(request.user, 'INSCRICAO', f"Inscrito no evento '{evento.titulo}' (ID: {evento.id}).")
            messages.success(request, 'Inscrição realizada com sucesso!')
            
    except IntegrityError:
        messages.error(request, 'Erro: Tentativa de inscrição duplicada.')
    except Exception as e:
        messages.error(request, f'Ocorreu um erro ao processar sua inscrição: {e}')
        
    return redirect('detalhe_evento', evento_id=evento.id)


@login_required
def meus_eventos(request):
    """Mostra eventos inscritos + eventos organizados"""
    
    inscricoes = Inscricao.objects.filter(usuario=request.user).select_related('evento')
    eventos_inscritos = [inscricao.evento for inscricao in inscricoes]

    # Eventos que o usuário organizou (independente do perfil)
    eventos_organizados = Evento.objects.filter(organizador=request.user)

    context = {
        'eventos_inscritos': eventos_inscritos,
        'eventos_organizados': eventos_organizados,
    }
    return render(request, 'pages/meus_eventos.html', context)
# --- Views de Gerenciamento e Auditoria ---

@login_required
@user_passes_test(is_organizador)
def gerenciar_certificados(request, evento_id):
    """Gerencia a emissão de certificados (Requisito 8)."""
    evento = get_object_or_404(
        Evento.objects.prefetch_related(
            Prefetch('inscricoes', queryset=Inscricao.objects.select_related('usuario'))
        ), 
        pk=evento_id
    )

    if evento.organizador != request.user:
        messages.error(request, 'Você não tem permissão para gerenciar certificados deste evento.')
        return redirect('detalhe_evento', evento_id=evento.id)

    if evento.data_fim > date.today():
        messages.warning(request, "Certificados só podem ser emitidos após a data de término do evento.")
        inscricoes_validas = []
    else:
        inscricoes_validas = evento.inscricoes.filter(presenca_confirmada=True)

    context = {
        'evento': evento,
        'inscricoes': inscricoes_validas, 
    }
    return render(request, 'pages/gerenciar_certificados.html', context)

@login_required
@user_passes_test(is_organizador)
def consulta_auditoria(request):
    """Exibe o histórico de auditoria (Requisito 10)."""
    auditoria = RegistroAuditoria.objects.select_related('usuario').all().order_by('-timestamp')
    
    context = {
        'registros': auditoria
    }
    
    log_auditoria(request.user, 'CONSULTA_AUDITORIA', "Consulta ao registro de auditoria.")
    
    return render(request, 'pages/consulta_auditoria.html', context)

# View para confirmação de presença (via AJAX, Requisito 5)
@login_required
@user_passes_test(is_professor_ou_organizador)
@transaction.atomic
def confirmar_presenca(request, inscricao_id):
    """Confirma a presença de um participante (apenas Professor/Organizador)."""
    inscricao = get_object_or_404(Inscricao, pk=inscricao_id)
    
    tem_permissao = inscricao.evento.organizador == request.user or \
                    inscricao.evento.professor_responsavel == request.user

    if not tem_permissao:
        return JsonResponse({'status': 'error', 'message': 'Sem permissão.'}, status=403)
        
    if inscricao.presenca_confirmada:
        inscricao.presenca_confirmada = False
        acao = 'PRESENCA_DESCONFIRMADA'
    else:
        inscricao.presenca_confirmada = True
        acao = 'PRESENCA_CONFIRMADA'
    
    inscricao.save()
    
    log_auditoria(
        request.user, 
        acao, 
        f"Presença de {inscricao.usuario.username} {acao.lower()} no evento '{inscricao.evento.titulo}'."
    )
    
    return JsonResponse({'status': 'success', 'presenca_confirmada': inscricao.presenca_confirmada})

@login_required
@user_passes_test(is_professor_ou_organizador)
@transaction.atomic
def emitir_certificado(request, inscricao_id):
    """Emite o certificado e gera o PDF (Requisito 8) usando xhtml2pdf."""
    inscricao = get_object_or_404(
        Inscricao.objects.select_related('evento', 'usuario'), 
        pk=inscricao_id
    )

    if inscricao.evento.data_fim > date.today():
        messages.error(request, "Certificado só pode ser emitido após o evento.")
        return redirect('gerenciar_certificados', evento_id=inscricao.evento.id)

    if not inscricao.presenca_confirmada:
        messages.error(request, "A presença do participante deve ser confirmada para emissão do certificado.")
        return redirect('gerenciar_certificados', evento_id=inscricao.evento.id)

    certificado, criado = Certificado.objects.get_or_create(inscricao=inscricao)
    
    # Renderiza o HTML (IMPORTANTE: Estilos CSS devem estar em <style> no template)
    html_string = render_to_string('pages/certificado_template.html', {
        'inscricao': inscricao,
        'certificado': certificado,
        'data_atual': date.today()
    })

    # --- BLOCO CONVERSOR DE PDF (xhtml2pdf) ---
    try:
        # 1. Cria um buffer de memória
        result_buffer = BytesIO()
        
        # 2. Converte o HTML para PDF (UTF-8 é importante para acentuação)
        pdf = pisa.pisaDocument(
            BytesIO(html_string.encode("UTF-8")), # HTML para ser lido
            dest=result_buffer                    # Buffer para escrita do PDF
        )
        
        if pdf.err:
             messages.error(request, "Erro ao gerar o PDF. Verifique o HTML/CSS do template.")
             return redirect('gerenciar_certificados', evento_id=inscricao.evento.id)

    except Exception as e:
        messages.error(request, f"Erro ao gerar o PDF: {e}")
        return redirect('gerenciar_certificados', evento_id=inscricao.evento.id)
    # ----------------------------------------
    
    log_auditoria(
        request.user, 
        'EMISSAO_CERTIFICADO', 
        f"Certificado para {inscricao.usuario.username} (Código: {certificado.codigo_validacao})."
    )
    
    # Retorna a resposta HTTP com o conteúdo do buffer
    response = HttpResponse(result_buffer.getvalue(), content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="certificado_{certificado.codigo_validacao}.pdf"'
    return response

def validar_certificado(request, codigo):
    """View para validação do certificado (Requisito 8)."""
    certificado = get_object_or_404(
        Certificado.objects.select_related('inscricao__evento', 'inscricao__usuario'), 
        codigo_validacao=codigo
    )
    
    return render(request, 'pages/validar_certificado.html', {'certificado': certificado})

# --- Views de Edição/Exclusão ---

@login_required
@user_passes_test(is_organizador)
@transaction.atomic
def editar_evento(request, evento_id):
    """Edita um evento existente (IMPORTAÇÃO LOCAL CRÍTICA)."""
    from .forms import EventoForm # CRÍTICO: Importação Local
    
    evento = get_object_or_404(Evento, pk=evento_id)
    
    if evento.organizador != request.user:
        messages.error(request, 'Você só pode editar eventos que você organizou.')
        return redirect('meus_eventos')
        
    if request.method == 'POST':
        form = EventoForm(request.POST, request.FILES, instance=evento)
        if form.is_valid():
            form.save()
            log_auditoria(request.user, 'EDICAO_EVENTO', f"Evento '{evento.titulo}' (ID: {evento.id}) editado.")
            messages.success(request, 'Evento atualizado com sucesso.')
            return redirect('meus_eventos')
    else:
        form = EventoForm(instance=evento)
        
    return render(request, 'pages/edit_evento.html', {'form': form, 'evento': evento})

@login_required
@user_passes_test(is_organizador)
@transaction.atomic
def excluir_evento(request, evento_id):
    """Exclui um evento existente."""
    evento = get_object_or_404(Evento, pk=evento_id)
    
    if evento.organizador != request.user:
        messages.error(request, 'Você só pode excluir eventos que você organizou.')
        return redirect('meus_eventos')
        
    if request.method == 'POST':
        titulo = evento.titulo
        evento_id_log = evento.id
        evento.delete()
        
        log_auditoria(request.user, 'EXCLUSAO_EVENTO', f"Evento '{titulo}' (ID: {evento_id_log}) excluído.")
        messages.success(request, 'Evento excluído com sucesso.')
        return redirect('meus_eventos')

    return render(request, 'pages/excluir_evento.html', {'evento': evento})