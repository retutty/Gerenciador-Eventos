from rest_framework import viewsets, permissions, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.throttling import UserRateThrottle
# Importação correta do módulo de transação
from django.db import transaction 
from datetime import date

# Importamos APENAS os modelos usados globalmente. Perfil é importado localmente abaixo.
from .models import Evento, Inscricao
from .serializers import EventoSerializer, InscricaoSerializer
from .utils import log_auditoria

# --- Permissões Customizadas (Requisito 9) ---

class IsParticipante(permissions.BasePermission):
    """Permissão para Professor ou Aluno (Participantes)"""
    def has_permission(self, request, view):
        if not request.user.is_authenticated:
            return False
        
        # IMPORTAÇÃO LOCAL: Quebra a circularidade no carregamento do módulo.
        from .models import Perfil
        try:
            perfil = request.user.perfil.perfil
            return perfil in ['ALUNO', 'PROFESSOR']
        except Perfil.DoesNotExist:
            return False

class IsOrganizadoreReadOnly(permissions.BasePermission):
    """Organizador tem permissão de leitura"""
    def has_permission(self, request, view):
        if not request.user.is_authenticated:
            return False
        if request.method in permissions.SAFE_METHODS:
             from .models import Perfil
             try:
                return request.user.perfil.perfil == 'ORGANIZADOR'
             except Perfil.DoesNotExist:
                 return False
        return False # Organizador não tem permissão de escrita na API

# --- Throttles Customizados (Requisito 3) ---

class EventoConsultaThrottle(UserRateThrottle):
    scope = 'eventos_consulta' 

class InscricaoParticipanteThrottle(UserRateThrottle):
    scope = 'inscricao_participante'


# --- ViewSets da API ---

class EventoViewSet(viewsets.ReadOnlyModelViewSet):
    """
    Requisito 3.1: API para listar eventos.
    """
    queryset = Evento.objects.filter(data_fim__gte=date.today()).order_by('data_inicio')
    serializer_class = EventoSerializer
    throttle_classes = [EventoConsultaThrottle] 
    
    def list(self, request, *args, **kwargs):
        # Requisito 10: Auditoria
        log_auditoria(request.user, 'API_CONSULTA', f"Consulta de eventos via API.")
        return super().list(request, *args, **kwargs)

class InscricaoViewSet(viewsets.GenericViewSet):
    """
    Requisito 3.2: API para inscrição em eventos.
    """
    queryset = Inscricao.objects.all()
    serializer_class = InscricaoSerializer
    permission_classes = [permissions.IsAuthenticated, IsParticipante]
    throttle_classes = [InscricaoParticipanteThrottle]

    @action(detail=False, methods=['post'], url_path='inscrever')
    # Uso correto do decorador importado de django.db
    @transaction.atomic 
    def inscrever(self, request):
        serializer = self.get_serializer(data=request.data)
        
        if serializer.is_valid():
            inscricao = serializer.save(usuario=request.user)
            
            # Requisito 10: Auditoria
            log_auditoria(request.user, 'API_INSCRICAO', f"Inscrição via API no evento '{inscricao.evento.titulo}' (ID: {inscricao.evento.id})")
            
            return Response({
                "message": "Inscrição realizada com sucesso.",
                "inscricao_id": inscricao.id,
                "evento_titulo": inscricao.evento.titulo
            }, status=status.HTTP_201_CREATED)
            
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
