from django.urls import path, include
from . import views 
from rest_framework import routers
from django.conf import settings
from django.conf.urls.static import static
# A importação da API agora deve funcionar com a estrutura de pastas corrigida
from .api_views import EventoViewSet, InscricaoViewSet
# Cria um router para a API
router = routers.DefaultRouter()
router.register(r'eventos', EventoViewSet, basename='api-eventos')
router.register(r'inscricoes', InscricaoViewSet, basename='api-inscricoes')

urlpatterns = [
    # Rotas da API
    path('api/', include(router.urls)),
    
    # Rotas de Usuário/Autenticação
    path('', views.home, name='home'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('registro/', views.registrar_usuario, name='registro'),
    path('confirmar-email/', views.confirmar_email, name='confirmar_email'),
    
    # Rotas de Eventos e Inscrição
    path('eventos/', views.lista_eventos, name='lista_eventos'),
    path('eventos/<int:evento_id>/', views.detalhe_evento, name='detalhe_evento'),
    path('eventos/<int:evento_id>/inscrever/', views.inscrever_evento, name='inscrever_evento'),
    path('meus-eventos/', views.meus_eventos, name='meus_eventos'),
    
    # Rotas de Gerenciamento (Organizador)
    path('evento/criar/', views.criar_evento, name='criar_evento'),
    path('evento/<int:evento_id>/editar/', views.editar_evento, name='editar_evento'),
    path('evento/<int:evento_id>/excluir/', views.excluir_evento, name='excluir_evento'),
    
    # Rotas de Auditoria e Presença
    path('auditoria/', views.consulta_auditoria, name='consulta_auditoria'),
    path('presenca/<int:inscricao_id>/confirmar/', views.confirmar_presenca, name='confirmar_presenca'),
    
    # Rotas de Certificado
    path('evento/<int:evento_id>/certificados/', views.gerenciar_certificados, name='gerenciar_certificados'),
    path('certificado/<int:inscricao_id>/emitir/', views.emitir_certificado, name='emitir_certificado'),
    path('certificado/validar/<uuid:codigo>/', views.validar_certificado, name='validar_certificado'),
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)