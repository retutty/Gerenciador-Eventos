# pages/utils.py

from django.apps import apps
from django.utils import timezone
from django.contrib.auth import get_user_model

# Definição do modelo de Auditoria de forma segura, após o Django carregar tudo.
def get_registro_auditoria_model():
    # O primeiro argumento é o nome da app ('pages'), o segundo é o nome do modelo
    return apps.get_model('pages', 'RegistroAuditoria')

def log_auditoria(user, acao, detalhes):
    """
    Registra uma ação no modelo RegistroAuditoria.
    Recebe o usuário que executou a ação, o nome da ação e detalhes.
    """
    try:
        # Pega o modelo de forma segura
        RegistroAuditoria = get_registro_auditoria_model()
        
        # Garante que o timestamp é no fuso horário correto
        timestamp = timezone.now()
        
        # Cria o registro de auditoria
        RegistroAuditoria.objects.create(
            usuario=user if user and user.is_authenticated else None,
            acao=acao,
            detalhes=detalhes,
            timestamp=timestamp
        )
    except Exception as e:
        # Se houver erro no log (por exemplo, durante migrações ou startup), apenas printa o erro.
        # print(f"Erro ao tentar logar auditoria: {e}")
        pass